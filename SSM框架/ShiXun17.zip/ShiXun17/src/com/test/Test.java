package com.test;

import com.entity.Dept;
import com.entity.Emp;
import com.entity.SysUser;
import com.service.DepartmentManageService;
import com.service.EmpManageService;
import com.service.impl.DepartmentManageServiceImpl;
import com.service.impl.EmpManageServiceImpl;

import java.sql.Date;
import java.util.ArrayList;


public class Test {

    public static void main(String[] args) throws Exception {
        //DepartmentManageService departmentManageService = new DepartmentManageServiceImpl();
        //EmpManageService empManageService = new EmpManageServiceImpl("王");
       // ArrayList<Dept> deptList = new ArrayList();
        //ArrayList<Emp> empList= new ArrayList();
        /*
        //测试dept分页查询函数
        deptList=departmentManageService.selectDept_byPage_byKeyWords(1,"a");
        System.out.println("查询结果"+deptList.size());
        for(int i=0;i<deptList.size();i++) {
            Dept d =new Dept();
            d=deptList.get(i);
            System.out.print(d.getId()+"  ");
            System.out.print(d.getName()+"  ");
            System.out.print(d.getAddress()+"  ");
            System.out.println();
        }

         */
        /*
        //测试emp分页查询函数
        empList=empManageService.selectEmp_byPage_byKeyWords(2,"王");
        System.out.println("查询结果"+empList.size());
        for(int i=0;i<empList.size();i++) {
            Emp e = new Emp();
            e=empList.get(i);
            System.out.print(e.getId()+"  ");
            System.out.print(e.getUsername()+"  ");
            System.out.println();
        }

         */
        /*
        //测试添加函数
        Dept d = new Dept();
        d.setName("天才");
        d.setAddress("天堂");
        DepartmentManageService departmentManageService =new DepartmentManageServiceImpl();
        departmentManageService.Dept_Add(d);

         */
        /*
        //测试添加函数
        Dept d = new Dept();
        d.setId(18);
        d.setName("天才");
        d.setAddress("天堂");
        DepartmentManageService departmentManageService =new DepartmentManageServiceImpl();
        departmentManageService.Dept_Modify(d);


        //测试删除函数 测试成功
        int id= 2;
        EmpManageService empManageService =new EmpManageServiceImpl();
        empManageService.Emp_Delete(id);

        //测试添加函数 测试成功
        EmpManageService empManageService =new EmpManageServiceImpl();
        Emp e = new Emp();
        e.setId(38);
        e.setUsername("测试");
        e.setAge(18);
        e.setSex("男");
        String date="2018-9-1";
        Date d=Date.valueOf(date);
        e.setHireDate(d);
        e.setHobby("写bug");
        e.setInfo("菜鸡");
        e.setImgUrl("images/FeiZihan.jpg");
        Dept dept = new Dept();
        dept.setId(1);
        dept.setName("市场部");
        dept.setAddress("非洲");
        e.setDept(dept);
        empManageService.Emp_Add(e);
         */
        //测试修改函数
        EmpManageService empManageService =new EmpManageServiceImpl();
        Emp e = new Emp();
        e.setId(38);
        e.setUsername("aaaaa2");
        e.setAge(18);
        e.setSex("男");
        String date="2018-9-1";
        Date d=Date.valueOf(date);
        e.setHireDate(d);
        e.setHobby("写bug");
        e.setInfo("菜鸡");
        e.setImgUrl("images/FeiZihan.jpg");
        Dept dept = new Dept();
        dept.setId(1);
        dept.setName("市场部");
        dept.setAddress("非洲");
        e.setDept(dept);
       empManageService.Emp_Modify(e);



    }
}
