package com.entity;

public class Dept {
    private  Integer id;
    private String name;
    private  String address;

    public Dept() {
    }
    public Dept(Integer id,String name, String address){
        this.id=id;
        this.name=name;
        this.address=address;

    }
    public void setId(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getAddress() {
        return address;
    }
}
