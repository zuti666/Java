package com.entity;

import java.util.Date;

public class Emp {
    private Integer id;
    private String username;
    private  int age;
    private String sex;
    private Date hireDate;
    private String hobby;
    private String info;
    private String imgUrl;
    private  Dept  dept ;

    public Integer getId() {
        return id;
    }

    public String getUsername() {
        return username;
    }

    public int getAge() {
        return age;
    }

    public String getSex() {
        return sex;
    }

    public Date getHireDate() {
        return hireDate;
    }

    public String getHobby() {
        return hobby;
    }

    public String getInfo() {
        return info;
    }

    public String getImgUrl() {
        return imgUrl;
    }

    public Dept getDept() {
        return dept;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public void setSex(String sex) {
        this.sex = sex;
    }

    public void setHireDate(Date hireDate) {
        this.hireDate = hireDate;
    }

    public void setHobby(String hobby) {
        this.hobby = hobby;
    }

    public void setInfo(String info) {
        this.info = info;
    }

    public void setImgUrl(String imgUrl) {
        this.imgUrl = imgUrl;
    }

    public void setDept(Dept dept) {
        this.dept = dept;
    }


}
