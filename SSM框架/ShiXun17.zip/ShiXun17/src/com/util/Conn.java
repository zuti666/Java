package com.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class Conn {

     public static  Connection  getConn(){
         Connection conn = null;
         try {
             // 1.加载驱动
             Class.forName("com.mysql.jdbc.Driver");
             // 2. 获得连接
             conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/ems_system?useUnicode=true&characterEncoding=utf8", "root", "root");

         } catch (ClassNotFoundException | SQLException e) {
             e.printStackTrace();
         }

        return  conn;
     }

}
