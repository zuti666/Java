package com.action;

import com.entity.Dept;
import com.entity.Emp;
import com.entity.SysUser;
import com.google.gson.Gson;
import com.service.DepartmentManageService;
import com.service.EmpManageService;
import com.service.SysUserService;
import com.service.impl.DepartmentManageServiceImpl;
import com.service.impl.EmpManageServiceImpl;
import com.service.impl.SysUserServiceImpl;
import com.util.MD5;
import com.util.MakeCheckCode;


import javax.servlet.*;
import javax.servlet.http.*;
import java.io.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.*;

public class SysServlet  extends HttpServlet {

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("text/html;charset=utf-8");
        req.setCharacterEncoding("utf-8");
        String path  =  req.getServletPath();

        if("/login.sys".equals(path)){
            // 登录操作
            doLogin(req, resp);
        }else if("/regist.sys".equals(path)){
            // 转到注册界面
            req.getRequestDispatcher("/jsp/register.jsp").forward(req, resp);
        }else if("/registerManage.sys".equals(path)){
            // 注册操作
            doRegister(req, resp);
        } else if("/deptManager.sys".equals(path)){
            try {
                toDeptManageJsp_byPage_byKeyWords(req,resp);
                //转发到
                req.getRequestDispatcher("/jsp/deptManager.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/empManage.sys".equals(path)){
            try {
                toEmpManage_byPage_byKeyWords(req,resp);
                //转发到
                req.getRequestDispatcher("/jsp/empManage.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/deptAdd.sys".equals(path)){
            try {
                deptAdd(req,resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                req.getRequestDispatcher("/jsp/deptManager.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/deptModify.sys".equals(path)){
            try {
                deptModify(req,resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                req.getRequestDispatcher("/jsp/deptManager.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }else if("/deptDelete.sys".equals(path)){
            try {
                deptDelete(req,resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                req.getRequestDispatcher("/jsp/deptManager.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/addEmp.sys".equals(path)){
            try {

                DepartmentManageService dms=new DepartmentManageServiceImpl();
                ArrayList<Dept> deptList=dms.selectAllDept();
                System.out.println("/empAdd.sys转到添加界面,查询部门"+deptList.size());
                EmpManageService empManageService = new EmpManageServiceImpl();
                int newID=empManageService.selectMaxID()+1;
                System.out.println("/empAdd.sys转到添加界面,查询部门"+newID);
                req.setAttribute("deptList",deptList);
                req.setAttribute("maxID",newID);
                req.getRequestDispatcher("/jsp/empAdd.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }else if("/empDelete.sys".equals(path)){
            try {
                empDelete(req, resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                req.getRequestDispatcher("/jsp/empManage.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }else if("/empModify.sys".equals(path)){
            try {
                //转到修改界面
                int id= Integer.valueOf(req.getParameter("id")) ;
                Emp emp = new Emp();
                EmpManageService empManageService = new EmpManageServiceImpl();
                emp = empManageService.selectEmp_byID(id);
                DepartmentManageService dms=new DepartmentManageServiceImpl();
                ArrayList<Dept> deptList=dms.selectAllDept();
                System.out.println("empModify.sys转到修改界面,查询部门"+deptList.size());
                req.setAttribute("deptList",deptList);
                req.setAttribute("id",id);
                req.setAttribute("emp",emp);
                System.out.println("empModify.sys转到修改界面获取deptname"+emp.getDept().getName());
                System.out.println("empModify.sys转到修改界面获取imgUrl"+emp.getImgUrl());
                System.out.println();
                req.getRequestDispatcher("/jsp/empModify.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }

        }else if("/empManageModify.sys".equals(path)){
            try {
                empManageModify(req, resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                //转发到
                req.getRequestDispatcher("/jsp/empManage.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/empManageAdd.sys".equals(path)){
            try {
                empManageAdd(req, resp);
                toEmpManage_byPage_byKeyWords(req,resp);
                req.getRequestDispatcher("/jsp/empManage.jsp").forward(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/upload.sys".equals(path)){
            try {
                System.out.println("跳转/upload.sys");
                upload(req, resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }else if("/download.sys".equals(path)){
            System.out.println("跳转/download.sys");
            //跳转
            try {
                download(req, resp);
                toEmpManage_byPage_byKeyWords(req,resp);
            } catch (Exception e) {
                e.printStackTrace();
            }
            req.getRequestDispatcher("/jsp/empManage.jsp").forward(req, resp);

        }else if("/MakeCode.sys".equals(path)){
            System.out.println("产生验证码/MakeCode.sys");
            MakeCode(req,resp);

        }else if("/checkCode.sys".equals(path)){
            System.out.println("验证验证码/checkCode.sys");
            checkCode(req, resp);
        }
    }

    private void MakeCode(HttpServletRequest request,HttpServletResponse response) throws IOException {
        // TODO Auto-generated method stub
        System.out.println("执行函数");
        MakeCheckCode mc=new MakeCheckCode();
        String str=mc.getCode(0,0,response.getOutputStream());
        request.getSession().setAttribute("checkCode1",str);
        System.out.println("MakeCode checkCode1"+(String)request.getSession().getAttribute("checkCode1"));
    }

    private void empDelete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        EmpManageService empManageService = new EmpManageServiceImpl();
        int idEmpDelete = Integer.valueOf(req.getParameter("idEmpDelete"));
        empManageService.Emp_Delete(idEmpDelete);
    }

    private void empManageAdd(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        EmpManageService empManageService = new EmpManageServiceImpl();
        Emp e =  new Emp();
        e.setId(Integer.valueOf(req.getParameter("id")));
        e.setUsername(req.getParameter("user-name"));
        e.setAge(Integer.valueOf(req.getParameter("age")));
        e.setHobby(req.getParameter("hobby"));
        e.setInfo(req.getParameter("uesr-info"));
        e.setSex(req.getParameter("sex"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date utilDate = sdf.parse(req.getParameter("user-date"));
        e.setHireDate(utilDate);
        String deptName = (req.getParameter("depart"));
        DepartmentManageService dms = new DepartmentManageServiceImpl();
        Dept dept = new Dept();
        dept=dms.selectDeptByName(deptName);
        e.setDept(dept);
        String fileName = req.getParameter("fileName");
        e.setImgUrl(fileName);
        System.out.println("Sys      fileName"+fileName);
        empManageService.Emp_Add(e);
    }
    private void empManageModify(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        EmpManageService empManageService = new EmpManageServiceImpl();
        Emp e =  new Emp();
        e.setUsername(req.getParameter("user-name"));
        e.setAge(Integer.valueOf(req.getParameter("age")));
        e.setHobby(req.getParameter("hobby"));
        e.setInfo(req.getParameter("uesr-info"));
        e.setSex(req.getParameter("sex"));
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
        Date utilDate = sdf.parse(req.getParameter("user-date"));
        e.setHireDate(utilDate);
        String deptName = (req.getParameter("depart"));
        System.out.println("empManageModify从页面获取user-name"+e.getUsername());
        System.out.println("empManageModify从页面获取deptName"+deptName);
        DepartmentManageService dms = new DepartmentManageServiceImpl();
        Dept dept = new Dept();
        dept=dms.selectDeptByName(deptName);
        e.setDept(dept);
        int id = Integer.valueOf(req.getParameter("id"));
        e.setId(id);
        String fileName = empManageService.selectImgUrl_byID(id);
        e.setImgUrl(fileName);
        System.out.println("empManageModify从页面获取imgUrl"+req.getParameter("fileName"));
        empManageService.Emp_Modify(e);
        //int maxPage = ((EmpManageServiceImpl) empManageService).getPageNum();
        //ArrayList<Emp> empArrayList = empManageService.selectEmp_byPage_byKeyWords(maxPage,null);
        //req.setAttribute("empList",empArrayList);
        //req.getRequestDispatcher("/jsp/empManage.jsp");

    }

    private void deptModify(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        int id = Integer.valueOf(req.getParameter("id"));
        System.out.println("修改ID"+id);
        String deptName = req.getParameter("deptName");
        String deptAddress=req.getParameter("deptAddress");
        Dept dept =  new Dept();
        dept.setId(id);
        dept.setName(deptName);
        dept.setAddress(deptAddress);
        DepartmentManageService departmentManageService = new DepartmentManageServiceImpl();
        departmentManageService.Dept_Modify(dept);
    }
    private void deptDelete(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        int idDelete =Integer.valueOf(req.getParameter("idDelete")) ;
        DepartmentManageService departmentManageService = new DepartmentManageServiceImpl();
        departmentManageService.Dept_Delete(idDelete);
    }
    private void deptAdd(HttpServletRequest req, HttpServletResponse resp) throws Exception {
          String deptName = req.getParameter("deptName");
          String deptAddress=req.getParameter("deptAddress");
          Dept dept =  new Dept();
          dept.setName(deptName);
          dept.setAddress(deptAddress);
          DepartmentManageService departmentManageService = new DepartmentManageServiceImpl();
          departmentManageService.Dept_Add(dept);
    }


    private void doRegister(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        String username=req.getParameter("username");
        String email=req.getParameter("email");
        String password=req.getParameter("password");
        MD5 md5=new MD5();
        password=md5.md5Change(password);
        SysUser sysUser=new SysUser();

        sysUser.setUsername(username);
        sysUser.setEmail(email);
        sysUser.setPassword(password);

        SysUserService sysUserService=new SysUserServiceImpl();
        resp.setContentType("text/html;charset=utf-8");
        PrintWriter out = resp.getWriter();
        try {
            if(sysUser.getUsername()=="" ||sysUser.getPassword()=="" ||sysUser.getEmail()==""){
                out.print("<script>");
                out.print("alert('不能为空！');");
                out.print("document.location='jsp/register.jsp';");
                out.print("</script>");
            }
            if(sysUserService.regist(sysUser)){
                toDeptManageJsp_byPage_byKeyWords(req,resp);
                out.print("<script>");
                out.print("alert('注册成功!');");
                out.print("document.location='jsp/deptManager.jsp';");
                out.print("</script>");
            }else {
                out.print("<script>");
                out.print("alert('用户名或邮箱已存在!');");
                out.print("document.location='jsp/register.jsp';");
                out.print("</script>");
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath()+"/jsp/register.jsp");
        }

    }

    /**
     * 登录
     * @param req
     * @param resp
     */
    public void  doLogin(HttpServletRequest req, HttpServletResponse resp)throws ServletException, IOException{
        String username = req.getParameter("username");
        String email = req.getParameter("username");
        String password = req.getParameter("password");
        String check=req.getParameter("remember-me");

        HttpSession session=req.getSession();
        session.setAttribute("user",username);

        MD5 md5=new MD5();
        password=md5.md5Change(password);
        SysUser sysUser = new SysUser();
        sysUser.setEmail(email);
        sysUser.setUsername(username);
        sysUser.setPassword(password);
        SysUserService sysUserService = new SysUserServiceImpl();
        resp.setContentType("text/html;charset=utf-8");
        req.setCharacterEncoding("utf-8");
        PrintWriter out = resp.getWriter();
        String checkCode=req.getParameter("checkCode");

        String randCode=(String)session.getAttribute("checkCode1");
        System.out.println("ranCode"+randCode);
        System.out.println("checkCode"+checkCode);
        try {
            System.out.print("执行查询操作前sysUser信息 name"+sysUser.getUsername()+"email"+sysUser.getEmail()+" password"+sysUser.getPassword());
            sysUser = sysUserService.login(sysUser);
            System.out.println("doLogin 查询结果得到用户名"+sysUser.getUsername());
            if(sysUser.getUsername()==null){
                //重定向
                out.print("<script>");
                out.print("alert('用户名或密码错误！');");
                out.print("document.location='jsp/login.jsp';");
                out.print("</script>");
            }else {
                if(!randCode.equals(checkCode)){
                    out.print("<script>");
                    out.print("alert('验证码输入有误!');");
                    out.print("document.location='jsp/login.jsp';");
                    out.print("</script>");
                }else {
                    setCookie(req, resp);
                    toDeptManageJsp_byPage_byKeyWords(req, resp);
                    req.getRequestDispatcher("/jsp/deptManager.jsp").forward(req, resp);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            resp.sendRedirect(req.getContextPath()+"/jsp/login.jsp");
        }

    }

    private void setCookie(HttpServletRequest req, HttpServletResponse resp) {
        if (req.getParameter("checkbox")!=null) {
            //记住密码:生成新的cookie用来保存账号密码
            //System.out.println("qqq");
            Cookie username1 = new Cookie("username",req.getParameter("username"));
            username1.setMaxAge(1296000);//设置cookie最长保存时间15天
            Cookie password1 = new Cookie("password",req.getParameter("password"));
            password1.setMaxAge(1296000);
            //覆盖旧的cookie
            resp.addCookie(username1);
            resp.addCookie(password1);
        } else
        {
            //System.out.println("www");
            Cookie [] cookies = req.getCookies();
            Cookie username1=null;
            Cookie password1=null;
            //寻找是否已经存在cookie
            for (Cookie cookie:cookies) {
                if (cookie.getName().equals("username")) {
                    username1=cookie;
                } else
                if (cookie.getName().equals("password")) {
                    password1=cookie;
                }
            }
            //若cookie存在则通过设置cookie保存时间为0的方法来删除cookie
            if (username1!=null) {
                username1.setMaxAge(0);
                resp.addCookie(username1);
            }
            if (password1!=null) {
                password1.setMaxAge(0);
                resp.addCookie(password1);
            }
        }
    }

    public void toDeptManageJsp_byPage_byKeyWords(HttpServletRequest req, HttpServletResponse resp) throws Exception {//分页查询
        ArrayList<Dept> deptList = new ArrayList();
        int page=1;
        //从页面获得页数
        if(req.getParameter("page")!=null){
        page=Integer.valueOf(req.getParameter("page"));
        }else{
            req.setAttribute("page",page);
        }
        String search="";
        //从页面获得查询信息
        if(req.getParameter("search")!=null){
            search=req.getParameter("search");
        }else{
            req.setAttribute("search",search);
        }
        System.out.println("查询关键字search"+search);
        //从数据库中查询数据
        DepartmentManageService departmentManageService = new DepartmentManageServiceImpl(search);
        deptList= departmentManageService.selectDept_byPage_byKeyWords(page,search);
        //放到request里
        req.setAttribute("deptList",deptList);
        int maxpage=1;
        maxpage=((DepartmentManageServiceImpl) departmentManageService). getPageNum();
        System.out.println("toDeptManageJsp_byPage_byKeyWords maxPage"+ maxpage);
        req.setAttribute("maxPage",maxpage);
        req.setAttribute("search",search);

    }
    private void toEmpManage_byPage_byKeyWords(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        ArrayList<Emp> empList = new ArrayList();
        int page=1;
        //从页面获得页数
        if(req.getParameter("page")!=null){
            page=Integer.valueOf(req.getParameter("page"));
        }else{
            req.setAttribute("page",page);
        }
        String search="";
        //从页面获得查询信息
        if(req.getParameter("search")!=null){
            search=req.getParameter("search");
        }else{
            req.setAttribute("search",search);
        }
        //从数据库中查询数据
        EmpManageService empManageService = new EmpManageServiceImpl(search);
        empList=empManageService.selectEmp_byPage_byKeyWords(page,search);
        System.out.println("执行查询函数结果"+empList.size());
        req.setAttribute("empList",empList);
        int maxpage=1;
        maxpage= ((EmpManageServiceImpl) empManageService).getPageNum();
        req.setAttribute("maxPage",maxpage);
        req.setAttribute("search",search);
    }
    public void download(HttpServletRequest request, HttpServletResponse response) throws Exception {
        // 获取图片路径，由员工id获得fileName
        String fileName = request.getParameter("fileName");
        System.out.println("员工图片路径fileName"+fileName);
        // 只有在有图片的基础上才能下载
        if(fileName!=null && !"".equals(fileName))
        {
            // 上传路径
            String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
            String uploadPath = getServletContext().getRealPath("/WEB-INF/upload/"+date);
            // 获取服务器中要下载的资源的路径
            OutputStream out = null;
            FileInputStream in =  null;
            try
            {
                in = new FileInputStream(new File(uploadPath,fileName));
                out = response.getOutputStream();
                response.setContentType("image/jpeg");
                byte[] b = new byte[2048];
                int len = 0;
                while ((len = in.read(b)) != -1)
                {
                    out.write(b, 0, len);
                }
            } catch (IOException e)
            {
                e.printStackTrace();
            } finally
            {
                try
                {
                    if (out != null)
                    {
                        out.close();
                    }

                    out = null;
                } catch (IOException e)
                {
                    e.printStackTrace();
                }

                try
                {
                    if (in != null)
                    {
                        in.close();
                    }

                    in = null;
                } catch (IOException e)
                {
                    e.printStackTrace();
                }
            }


        }


    }

    /**
     * 文件上传
     * @param req
     * @param resp
     * @throws ServletException
     * @throws IOException
     */
    private void upload(HttpServletRequest req, HttpServletResponse resp) throws Exception {
        int id=Integer.parseInt(req.getParameter("id"));
        String dataURL = req.getParameter("image");
        System.out.println("SysServlet/upload id"+id+" dataURL"+dataURL);
        // 将dataURL开头的非base64字符删除
        String base64 = dataURL.substring(dataURL.indexOf(",") + 1);

        // 上传路径
        String date = new SimpleDateFormat("yyyy-MM-dd").format(new Date());
        String uploadPath = getServletContext().getRealPath("/WEB-INF/upload/"+date);
        System.out.println("上传路径 "+uploadPath);
        // 上传文件名字
        String uploadFilename = UUID.randomUUID().toString()+".jpg";
        System.out.println("上传文件名字"+uploadFilename);
        File file = new File(uploadPath,uploadFilename);
        if(!file.getParentFile().exists()){
            file.getParentFile().mkdirs();//创建父级文件路径
        }
        // 创建输出流
        FileOutputStream write = new FileOutputStream(file);
        // 将图片base64文本转为byte数组
        byte[] decoderBytes = Base64.getDecoder().decode(base64);
        for(int i=0;i<decoderBytes.length;++i) {
            if (decoderBytes[i] < 0) {//调整异常数据
                decoderBytes[i] += 256;
            }
        }

        write.write(decoderBytes);
        write.close();

        // 如果想保存图片路径至数据库表中，需要做sql操作
        EmpManageService ems=new EmpManageServiceImpl();
        ems.Img(uploadFilename,id);

        // 构建返回值json格式
        Map map = new HashMap<String, Object>();
        map.put("result", "ok");
        map.put("fileName",uploadFilename);
        System.out.println(map);
        Gson gson = new Gson();
        resp.getWriter().print(gson.toJson(map));

    }
    public void checkCode(HttpServletRequest request, HttpServletResponse response) throws IOException {
        boolean flag=false;
        response.setContentType("text/html;charset=utf-8");
        PrintWriter out = response.getWriter();
        request.setCharacterEncoding("utf-8");
        String checkCode=request.getParameter("checkCode");
        HttpSession session=request.getSession();
        String randCode=(String)session.getAttribute("checkCode1");
        if(!randCode.equals(checkCode)){
            flag=false;
        }else{
            flag=true;
        }
        out.print(flag);
        out.flush();
        out.close();

    }



}

