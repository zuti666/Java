package com.dao.impl;

import com.dao.SysUserDao;
import com.entity.SysUser;
import com.util.JdbcUtil;

import java.sql.PreparedStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class SysUserDaoImpl implements SysUserDao {
    @Override
    public SysUser selectUserByUserNameAndPass(SysUser user) throws Exception {
        String sql="select * from t_sysuser where (username=? or email=?) and password=?";
        PreparedStatement ps=JdbcUtil.getPreparedStatement(sql);
        ps.setString(1,user.getUsername());
        ps.setString(2,user.getEmail());
        ps.setString(3,user.getPassword());
        ResultSet rs=ps.executeQuery();
        SysUser sysUser=new SysUser();
        while(rs.next()){
            sysUser.setUsername(rs.getString("username"));
            sysUser.setEmail((rs.getString("email")));
            sysUser.setPassword(rs.getString("password"));
        }
        JdbcUtil.closeAll(JdbcUtil.getConn(),ps,rs);
        return sysUser;
    }

    @Override
    public boolean insertUser(SysUser user) throws Exception {
        boolean flag=false;
        String sql1="select * from t_sysuser where (username=? or email=?)";
        PreparedStatement ps1=JdbcUtil.getPreparedStatement(sql1);
        ps1.setString(1,user.getUsername());
        ps1.setString(2,user.getEmail());
        ResultSet rs=ps1.executeQuery();
        if(!rs.next() &&user.getUsername()!="" &&user.getEmail()!="" &&user.getPassword()!=""){
            String sql="insert into t_sysuser(username,password,email) values(?,?,?)";
            PreparedStatement ps=JdbcUtil.getPreparedStatement(sql);
            ps.setString(1,user.getUsername());
            ps.setString(2,user.getPassword());
            ps.setString(3,user.getEmail());
            ps.executeUpdate();
            flag=true;
        }else {
            flag=false;
        }
        return flag;
    }

}
