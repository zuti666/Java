package com.dao.impl;

import com.dao.DepartmentManageDao;
import com.entity.Dept;
import com.entity.SysUser;
import com.util.JdbcUtil;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class DepartmentManageDaoImpl implements DepartmentManageDao {

    @Override
    public ArrayList<Dept> selectDept_byPage_byKeyWords(int beginRow, int pageSize,String search) throws Exception {
        //传入的参数nowPage为开始查询的记录数，
        String sql;
        if(search!=""){
            sql="select * from t_dept where name like '%"+search+"%' limit ?,?" ;
        }else{
            sql = "select * from t_dept limit ?,?";
        }
        PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
        ps.setInt(1, beginRow);
        ps.setInt(2, pageSize);
        ResultSet rs = ps.executeQuery();
        ArrayList<Dept> deptList = new ArrayList<>();
        while (rs.next()) {
            Dept dept = new Dept();
            dept.setId(rs.getInt("id"));
            dept.setName(rs.getString("name"));
            dept.setAddress(rs.getString("addr"));
            deptList.add(dept);
        }
        System.out.println("查询结果"+deptList.size());

        return deptList;

    }


    @Override
    public int maxRows(String search) {
        int maxRow = 0;
        String sql;
        try {
            if(search!=""){
                System.out.println("DepartmentManagerDaoImpl.maxRows查询的"+search);
                sql="select * from t_dept where name like '%"+search+"%' " ;
            }else{
            sql = "select * from t_dept ";
            }
            PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                maxRow = maxRow + 1;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return maxRow;
    }

    @Override
    public int DeptAdd(Dept d) {
        int rtn=0;
        try{
            String sql = "insert into t_dept(name,addr)values(?,?)";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setString(1,d.getName());
            ps.setString(2,d.getAddress());
            rtn=ps.executeUpdate();
            ps.close();

        }catch (Exception e1){
            e1.printStackTrace();
        }

        return rtn;

    }

    @Override
    public int DeptModify(Dept d) {
        int rtn=0;
        try{

            String sql = "update t_dept set name=?,addr=? where id=? ";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setString(1,d.getName());
            ps.setString(2,d.getAddress());
            ps.setInt(3,d.getId());
            rtn=ps.executeUpdate();
            ps.close();
        }catch (Exception e1){
            e1.printStackTrace();
        }
        return rtn;
    }

    @Override
    public int DeptDelete(int id) {
        int rtn =0;
        try{
            String sql = "delete from t_dept where id=?";
            PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,id);
            rtn = ps.executeUpdate();
            System.out.println("DeptDelete id"+id);
        }catch(Exception e){
            e.printStackTrace();
        }
        return rtn;
    }

    @Override
    public ArrayList<Dept> DeptSelectAllDept() throws Exception {
        //传入的参数nowPage为开始查询的记录数，
        String sql = "select * from t_dept ";
        PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
        ResultSet rs = ps.executeQuery();
        ArrayList<Dept> deptList = new ArrayList<>();
        while (rs.next()) {
            Dept dept = new Dept();
            dept.setId(rs.getInt("id"));
            dept.setName(rs.getString("name"));
            dept.setAddress(rs.getString("addr"));
            deptList.add(dept);
        }
        System.out.println("查询结果"+deptList.size());

        return deptList;
    }

    @Override
    public Dept selctDept_byName(String deptName) throws Exception {
        String sql = "select * from t_dept where name= ?";
        PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
        ps.setString(1,deptName );
        ResultSet rs = ps.executeQuery();
        Dept dept = new Dept();
        if(rs.first()){
            dept.setId(rs.getInt("id"));
            dept.setName(rs.getString("name"));
            dept.setAddress(rs.getString("addr"));
        }
        rs.close();
        ps.close();

        return dept;
    }


}
