package com.dao.impl;

import com.dao.EmpManageDao;
import com.entity.Dept;
import com.entity.Emp;
import com.util.JdbcUtil;

import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;

public class EmpManageDaoImpl implements EmpManageDao {
    @Override
    public ArrayList<Emp> selectEmp_byPage_byKeyWords(int nowPage, int pageSize,String search) throws Exception {
        //传入的参数nowPage为当前页面，每页记录数为pageSize
        String sql;
        if(search!=""){
            sql="select * from t_emp where username like '%"+search+"%' limit ?,?" ;
        }else{
            sql = "select * from t_emp limit ?,?";
            System.out.println("执行");
        }
        PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
        ps.setInt(1,nowPage);
        ps.setInt(2,pageSize);
        ResultSet rs =  ps.executeQuery();
        ArrayList<Emp> empList =  new ArrayList<>();
        while (rs.next()){
            Emp emp = new Emp();
            emp.setId(rs.getInt("id"));
            emp.setUsername(rs.getString("username"));
            System.out.println("username"+rs.getString("username"));
            emp.setAge(rs.getInt("age"));
            emp.setSex(rs.getString("sex"));
            System.out.println("date"+rs.getDate("hireDate"));
            emp.setHireDate(rs.getDate("hireDate"));
            emp.setHobby(rs.getString("hobby"));
            emp.setInfo(rs.getString("info"));
            emp.setImgUrl(rs.getString("imgUrl"));
            Dept dept=selectDept_byDeptID(rs.getInt("dept_id"));
            emp.setDept(dept);
            empList.add(emp);
        }

        rs.close();
        ps.close();
        return empList;

    }

    @Override
    public int EmpAdd(Emp e) {
        int rtn=0;
        try{
            String sql = "insert into t_emp(id,username,age,sex,hireDate,hobby,info,imgUrl,dept_id)values(?,?,?,?,?,?,?,?,?)";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,e.getId());
            ps.setString(2,e.getUsername());
            ps.setInt(3,e.getAge());
            ps.setString(4,e.getSex());

            java.sql.Date date=new java.sql.Date(e.getHireDate().getTime());
            ps.setDate(5, date);

            ps.setString(6,e.getHobby());
            ps.setString(7,e.getInfo());
            ps.setString(8,e.getImgUrl());
            Dept dept = new Dept();
            dept.setId(e.getDept().getId());
            dept.setName(e.getDept().getName());
            dept.setAddress(e.getDept().getAddress());
            ps.setInt(9,dept.getId());
            rtn=ps.executeUpdate();
            ps.close();


        }catch (Exception e1){
            e1.printStackTrace();
        }
        return rtn;
    }

    @Override
    public int EmpModify(Emp e) {
        int rtn=0;
        try{
            String sql = "update t_emp  set age=?,sex=?,hireDate=?,hobby=?,info=?,imgUrl=?,dept_id=?,username=? where id=?";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,e.getAge());
            ps.setString(2,e.getSex());
            java.sql.Date date=new java.sql.Date(e.getHireDate().getTime());
            ps.setDate(3, date);
            ps.setString(4,e.getHobby());
            ps.setString(5,e.getInfo());
            ps.setString(6,e.getImgUrl());

            Dept dept = new Dept();
            dept.setId(e.getDept().getId());
            dept.setName(e.getDept().getName());
            dept.setAddress(e.getDept().getAddress());

            ps.setInt(7,dept.getId());

            ps.setString(8,e.getUsername());

            ps.setInt(9,e.getId());
            rtn=ps.executeUpdate();
            ps.close();

        }catch (Exception e1){
            e1.printStackTrace();
        }
        return rtn;
    }

    @Override
    public int EmpDelete(int id) {
        int rtn =0;
        try{
            String sql = "delete from t_emp where id=?";
            PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,id);
            rtn = ps.executeUpdate();
            ps.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return rtn;
    }

    @Override
    public ArrayList<Emp> selectEmp_byKeyWords(String s) {//由关键字s模糊查询姓名
        ArrayList<Emp> empArrayList = new ArrayList();
        try{
            //传入的参数nowPage为当前页面，每页记录数为pageSize
            String sql="select * from t_emp where uname like '% "+s+" %' ";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ResultSet rs =  ps.executeQuery();
            while (rs.next()){
                Emp emp = new Emp();
                emp.setId(rs.getInt("id"));
                emp.setUsername(rs.getString("username"));
                emp.setAge(rs.getInt("age"));
                emp.setSex(rs.getString("sex"));
                Dept dept=selectDept_byDeptID(rs.getInt("dept_id"));
                emp.setDept(dept);
                emp.setHireDate(rs.getDate("hireDate"));
                emp.setHobby(rs.getString("hobby"));
                emp.setInfo(rs.getString("info"));
                emp.setImgUrl(rs.getString("imgUrl"));
                empArrayList.add(emp);
            }
            rs.close();
            ps.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return empArrayList;
    }

    @Override
    public Dept selectDept_byDeptID(int id) {
        Dept dept =new Dept();
        try{
            String sql = "select * from t_dept where id=?";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,id);
            ResultSet rs =  ps.executeQuery();
            if (rs.first()){

                dept.setId(rs.getInt("id"));
                dept.setName(rs.getString("name"));
                dept.setAddress(rs.getString("addr"));
            }
            rs.close();
            ps.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return dept;
    }

    @Override
    public int maxRows(String search) {
        int maxRow = 0;
        String sql;
        try {
            if(search!=""){
                sql="select * from t_emp where username like '%"+search+"%'  " ;
            }else{
                sql = "select * from t_emp ";
            }
            PreparedStatement ps = JdbcUtil.getPreparedStatement(sql);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                maxRow = maxRow + 1;
            }
            rs.close();
            ps.close();

        } catch (Exception e) {
            e.printStackTrace();
        }
        return maxRow;
    }

    @Override
    public int Img(String uploadFilename, int id) {
        int rtn=0;
        try{
            String sql = "update t_emp  set imgUrl= ? where id=?";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setString(1,uploadFilename);
            ps.setInt(2,id);
            rtn=ps.executeUpdate();
            ps.close();

        }catch (Exception e){
            e.printStackTrace();
        }
        System.out.println("EmpManageDao 执行数据库添加操作"+rtn);
        return rtn;
    }

    @Override
    public String selectImgUrl_byID(int id) {
        String imgUrl = null;
        try{
            String sql = "select imgUrl from t_emp where id=?";
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,id);
            ResultSet rs =  ps.executeQuery();
            if (rs.first()){
                imgUrl = rs.getString("imgUrl");
            }
            rs.close();
            ps.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return imgUrl;
    }

    @Override
    public Emp selectEmp_byID(int id) {
        Emp emp = new Emp();
        try{
            //传入的参数nowPage为当前页面，每页记录数为pageSize
            String sql="select * from t_emp where id = ? " ;
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ps.setInt(1,id);
            ResultSet rs =  ps.executeQuery();
            while (rs.next()){
                emp.setId(id);
                emp.setUsername(rs.getString("username"));
                emp.setAge(rs.getInt("age"));
                emp.setSex(rs.getString("sex"));
                Dept dept=selectDept_byDeptID(rs.getInt("dept_id"));
                emp.setDept(dept);
                emp.setHireDate(rs.getDate("hireDate"));
                emp.setHobby(rs.getString("hobby"));
                emp.setInfo(rs.getString("info"));
                emp.setImgUrl(rs.getString("imgUrl"));
            }
            rs.close();
            ps.close();

        }catch(Exception e){
            e.printStackTrace();
        }
        return emp;

    }

    @Override
    public int selectMaxID() {
        int maxID=100;
        try{
            //传入的参数nowPage为当前页面，每页记录数为pageSize
            String sql="select max(id) from t_emp " ;
            PreparedStatement ps =  JdbcUtil.getPreparedStatement(sql);
            ResultSet rs =  ps.executeQuery();
            if (rs.first()){
               maxID=rs.getInt(1);
            }


        }catch(Exception e){
            e.printStackTrace();
        }
        return maxID;
    }
}
