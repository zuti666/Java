package com.dao;

import com.entity.Dept;
import com.entity.Emp;
import com.entity.SysUser;

import java.util.ArrayList;
import java.util.List;

public interface DepartmentManageDao {
    public ArrayList<Dept> selectDept_byPage_byKeyWords(int beginRow,int pageSize,String search)throws Exception;//由关键字模糊查询姓名信息分页显示
    public int maxRows(String search) throws Exception;//查询最大记录数
    public int DeptAdd(Dept d);//添加员工信息
    public int DeptModify(Dept d);//修改员工信息
    public int DeptDelete(int id);//由编号删除员工

    public ArrayList<Dept> DeptSelectAllDept() throws Exception;

    public Dept selctDept_byName(String deptName) throws Exception;
}
