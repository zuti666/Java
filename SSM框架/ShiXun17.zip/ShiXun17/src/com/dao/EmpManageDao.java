package com.dao;

import com.entity.Dept;
import com.entity.Emp;

import java.util.ArrayList;

public interface EmpManageDao {
    public ArrayList<Emp> selectEmp_byPage_byKeyWords(int beginRow, int pageSize,String search)throws Exception;
    public int EmpAdd(Emp e);//添加员工信息
    public int EmpModify(Emp e);//修改员工信息
    public int EmpDelete(int id);//由编号删除员工
    public ArrayList<Emp> selectEmp_byKeyWords(String s);//由关键字模糊查询姓名信息
    public Dept selectDept_byDeptID(int id);//由部门编号查询部门
    int maxRows(String search);

    public  int Img(String uploadFilename, int id);
    public String selectImgUrl_byID(int id);

    public  Emp selectEmp_byID(int id);

    public  int selectMaxID();
}
