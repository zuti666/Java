package com.dao;

import com.entity.SysUser;

public interface SysUserDao {

    public SysUser selectUserByUserNameAndPass(SysUser user)throws Exception;
    public boolean insertUser(SysUser user) throws Exception;
}
