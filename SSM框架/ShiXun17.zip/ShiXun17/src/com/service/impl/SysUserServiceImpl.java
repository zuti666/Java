package com.service.impl;

import com.dao.SysUserDao;
import com.dao.impl.SysUserDaoImpl;
import com.entity.SysUser;
import com.service.SysUserService;
import com.util.JdbcUtil;

import java.sql.SQLException;

public class SysUserServiceImpl implements SysUserService {

    @Override
    public SysUser login(SysUser user) throws Exception {
        SysUserDao sysUserDao = new SysUserDaoImpl();
        return sysUserDao.selectUserByUserNameAndPass(user);
    }

    @Override
    public boolean regist(SysUser sysUser) throws SQLException {
        SysUserDao dao=new SysUserDaoImpl();
        boolean flag=false;
        try{
            if(dao.insertUser(sysUser)){
                flag=true;
            }else {
                flag=false;
            }
        }catch (Exception e){
            e.printStackTrace();
            JdbcUtil.rollback();
        }
        return flag;

    }
}
