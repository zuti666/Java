package com.service.impl;

import com.dao.EmpManageDao;
import com.dao.impl.EmpManageDaoImpl;
import com.entity.Emp;
import com.service.EmpManageService;

import java.util.ArrayList;

public class EmpManageServiceImpl implements EmpManageService {
    private int pageSize;//每页记录数
    private int maxRows; //记录条数
    private int pageNum; //总页数
    public EmpManageServiceImpl() throws Exception {
        System.out.println("EmpManageServiceImpl执行无参数初始化函数");
        pageSize=5;
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        maxRows=empManageDao.maxRows(""); //查询数据库得到最大记录数
        System.out.println("EmpManageServiceImpl最大纪录条数："+maxRows);
        //计算页面数
        pageNum =  maxRows/pageSize;
        int yu = maxRows%pageSize;
        if(yu!=0){
            pageNum=pageNum+1;
        }
        System.out.println("EmpManageServiceImpl最大页面数"+pageNum);
    }
    public EmpManageServiceImpl(String search) throws Exception {
        System.out.println("EmpManageServiceImpl执行有参数初始化函数");
        pageSize=5;
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        maxRows=empManageDao.maxRows(search); //查询数据库得到最大记录数
        System.out.println("EmpManageServiceImpl最大纪录条数："+maxRows);
        //计算页面数
        pageNum =  maxRows/pageSize;
        int yu = maxRows%pageSize;
        if(yu!=0){
            pageNum=pageNum+1;
        }
        System.out.println("EmpManageServiceImpl最大页面数"+pageNum);
    }


    public int getPageNum() {
        return pageNum;
    }

    @Override
    public ArrayList<Emp> selectEmp_byPage_byKeyWords(int nowPage,String search) throws Exception {
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        ArrayList<Emp> empList = new ArrayList();
        //保证页面在可查询范围内
        if(nowPage<=0){
            nowPage=1;
        }
        if(nowPage>pageNum){
            nowPage=pageNum;
        }
        int beginRow = (nowPage-1)*pageSize;
        System.out.println("执行分页查询函数：beginRow "+beginRow +" pageSize "+pageSize );
        empList=empManageDao.selectEmp_byPage_byKeyWords(beginRow,pageSize,search);
        return empList;
    }

    @Override
    public int Emp_Add(Emp e) {
        EmpManageDao empManageDao =new EmpManageDaoImpl();
        return empManageDao.EmpAdd(e);
    }

    @Override
    public int Emp_Modify(Emp e) {
        EmpManageDao empManageDao =new EmpManageDaoImpl();
        return empManageDao.EmpModify(e);
    }

    @Override
    public int Emp_Delete(int id) {
        EmpManageDao empManageDao =new EmpManageDaoImpl();
        return empManageDao.EmpDelete(id);
    }

    @Override
    public void Img(String uploadFilename, int id) {
        //将文件路径存放到数据库中
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        int i= empManageDao.Img(uploadFilename,id);
        System.out.println("EmpManageService 执行Img");

    }

    @Override
    public String selectImgUrl_byID(int id) {
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        String  fileName= empManageDao.selectImgUrl_byID(id);
        System.out.println("empManageServlet查询到的imgUrl"+fileName);

        return fileName;
    }

    @Override
    public Emp selectEmp_byID(int id) {
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        Emp emp = empManageDao.selectEmp_byID(id);
        return emp;
    }

    @Override
    public int selectMaxID() {
        EmpManageDao empManageDao = new EmpManageDaoImpl();
        return  empManageDao.selectMaxID();
    }

}
