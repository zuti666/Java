package com.service.impl;

import com.dao.DepartmentManageDao;
import com.dao.EmpManageDao;
import com.dao.impl.DepartmentManageDaoImpl;
import com.dao.impl.EmpManageDaoImpl;
import com.entity.Dept;
import com.service.DepartmentManageService;

import java.util.ArrayList;

public class DepartmentManageServiceImpl  implements DepartmentManageService {
    private int pageSize;//每页记录数
    private int maxRows; //记录条数
    private int pageNum; //总页数


    public DepartmentManageServiceImpl() throws Exception {
        System.out.println("DepartmentManaeServiceImpl执行无参数初始化函数");
        pageSize=5;
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        maxRows=departmentManageDao.maxRows(""); //查询数据库得到最大记录数
        System.out.println("DepartmentManaeServiceImpl最大纪录条数："+maxRows);
        //计算页面数
        pageNum =  maxRows/pageSize;
        int yu = maxRows%pageSize;
        if(yu!=0){
            pageNum=pageNum+1;
        }
        System.out.println("DepartmentManaeServiceImpl最大页面数"+pageNum);
    }
    public DepartmentManageServiceImpl(String search) throws Exception {
        System.out.println("DepartmentManaeServiceImpl执行有参数初始化函数");
        pageSize=5;
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        maxRows=departmentManageDao.maxRows(search); //查询数据库得到最大记录数
        System.out.println("DepartmentManaeServiceImpl最大纪录条数："+maxRows);
        //计算页面数
        pageNum =  maxRows/pageSize;
        int yu = maxRows%pageSize;
        if(yu!=0){
            pageNum=pageNum+1;
        }
        System.out.println("DepartmentManaeServiceImpl最大页面数"+pageNum);
        //

    }
    public int getPageNum() {
        return pageNum;
    }


    @Override
    public ArrayList<Dept> selectDept_byPage_byKeyWords(int nowPage, String search) throws Exception {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        ArrayList<Dept> deptList = new ArrayList();
        //保证页面在可查询范围内
        if(nowPage>pageNum){
            nowPage=pageNum;
        }
        if(nowPage<=0){
            nowPage=1;
        }
        System.out.println("传入的参数"+nowPage);
        int beginRow = (nowPage-1)*pageSize;
        System.out.println("执行分页查询函数：beginRow "+beginRow +" pageSize "+pageSize);
        deptList=departmentManageDao.selectDept_byPage_byKeyWords(beginRow,pageSize,search);
        return deptList;
    }

    @Override
    public int Dept_Add(Dept d) {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        return departmentManageDao.DeptAdd(d);
    }

    @Override
    public int Dept_Modify(Dept d) {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        return departmentManageDao.DeptModify(d);
    }

    @Override
    public int Dept_Delete(int id) {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        return departmentManageDao.DeptDelete(id);
    }

    @Override
    public ArrayList<Dept> selectAllDept() throws Exception {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        return departmentManageDao.DeptSelectAllDept();
    }

    @Override
    public Dept selectDeptByName(String deptName) throws Exception {
        DepartmentManageDao departmentManageDao = new DepartmentManageDaoImpl();
        return departmentManageDao.selctDept_byName(deptName);
    }
}
