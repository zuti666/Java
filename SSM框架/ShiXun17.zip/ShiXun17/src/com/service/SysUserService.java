package com.service;

import com.entity.SysUser;

import java.sql.SQLException;

public interface SysUserService {

    public SysUser login(SysUser user )throws Exception; //判断

    boolean regist(SysUser sysUser) throws SQLException;
}
