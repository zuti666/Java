package com.service;

import com.entity.Dept;
import com.entity.Emp;

import java.util.ArrayList;

public interface EmpManageService {
    public ArrayList<Emp> selectEmp_byPage_byKeyWords(int nowPage,String search) throws Exception;
    public  int Emp_Add(Emp e);
    public  int Emp_Modify(Emp e);
    public int Emp_Delete(int id);
    public  void Img(String uploadFilename, int id);
    public String selectImgUrl_byID(int id);

   public Emp selectEmp_byID(int id);

    public  int selectMaxID();
}
