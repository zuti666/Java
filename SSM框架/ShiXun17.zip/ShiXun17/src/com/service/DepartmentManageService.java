package com.service;

import com.entity.Dept;
import com.entity.Emp;
import com.entity.SysUser;

import java.util.ArrayList;

public interface DepartmentManageService {
    public ArrayList<Dept>  selectDept_byPage_byKeyWords(int nowPage,String search) throws Exception;
    public  int Dept_Add(Dept d);
    public  int Dept_Modify(Dept d);
    public  int Dept_Delete(int id);

    public ArrayList<Dept> selectAllDept() throws Exception;

    public Dept selectDeptByName(String deptName) throws Exception;
}
